(() => {
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];
  const initial = {coins:250,wins:0,trophies:0,owned:[0],selected:0,dailyClaimed:false,playerId:"MS-"+(1000+Math.floor(Math.random()*9000)),lastDaily:""};
  let data;
  try { data = {...initial, ...JSON.parse(localStorage.getItem("makenStarsSave") || "{}")}; } catch { data = {...initial}; }
  const fighters = [
    {name:"Nova",emoji:"🌟",desc:"Быстрый универсал",cost:0,color:"linear-gradient(135deg,#58a4ff,#4645b7)"},
    {name:"Блейз",emoji:"🔥",desc:"Сильная атака",cost:300,color:"linear-gradient(135deg,#ff9a42,#d64252)"},
    {name:"Луна",emoji:"🌙",desc:"Мастер энергии",cost:500,color:"linear-gradient(135deg,#bd83ff,#5d48bc)"},
    {name:"Танк",emoji:"🛡️",desc:"Крепкая защита",cost:700,color:"linear-gradient(135deg,#62d6a4,#238a7a)"}
  ];
  let score=0, player={x:17,y:67}, bots=[{id:"bot1",x:70,y:19,hp:2},{id:"bot2",x:74,y:69,hp:2}], battleTimer=null;
  function save(){localStorage.setItem("makenStarsSave",JSON.stringify(data));renderStats();}
  function renderStats(){
    $("#coins").textContent=data.coins;$("#wins").textContent=data.wins;$("#trophies").textContent=data.trophies;$("#owned").textContent=data.owned.length;$("#playerId").textContent=data.playerId;
  }
  function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");clearTimeout(toast.t);toast.t=setTimeout(()=>el.classList.remove("show"),2200);}
  function page(name){$$(".screen").forEach(s=>s.classList.toggle("active",s.id===name));if(name==="fighters")renderFighters();if(name==="profile")renderStats();}
  function renderFighters(){
    $("#fighterList").innerHTML=fighters.map((f,i)=>{const has=data.owned.includes(i),sel=data.selected===i;return `<article class="fighter"><div class="fighter-art" style="background:${f.color}">${f.emoji}</div><h3>${f.name}</h3><p>${f.desc}</p><button data-fighter="${i}" class="${sel?"selected":""}">${sel?"ВЫБРАН":has?"ВЫБРАТЬ":`ОТКРЫТЬ · ${f.cost} 🪙`}</button></article>`}).join("");
  }
  function renderPlayer(){const p=$("#player");p.style.left=player.x+"%";p.style.top=player.y+"%";p.querySelector("span").textContent=fighters[data.selected].emoji;}
  function renderBots(){bots.forEach(b=>{const el=$("#"+b.id);if(el){el.style.left=b.x+"%";el.style.top=b.y+"%";el.style.display=b.hp>0?"grid":"none";}})}
  function startBattle(){score=0;player={x:17,y:67};bots=[{id:"bot1",x:70,y:19,hp:2},{id:"bot2",x:74,y:69,hp:2}];$("#score").textContent=score;$("#arenaMessage").textContent="Двигайся и нажимай АТАКА!";$("#projectiles").innerHTML="";page("battle");renderPlayer();renderBots();}
  function move(dx,dy){if(!$("#battle").classList.contains("active"))return;player.x=Math.max(5,Math.min(87,player.x+dx));player.y=Math.max(5,Math.min(82,player.y+dy));renderPlayer();}
  function attack(superAttack=false){
    if(!$("#battle").classList.contains("active"))return;
    const alive=bots.filter(b=>b.hp>0);if(!alive.length){finishBattle();return;}
    const target=alive.sort((a,b)=>Math.hypot(a.x-player.x,a.y-player.y)-Math.hypot(b.x-player.x,b.y-player.y))[0];
    const projectile=document.createElement("div");projectile.className="projectile";projectile.style.left=(player.x+3)+"%";projectile.style.top=(player.y+2)+"%";$("#projectiles").appendChild(projectile);
    const from={x:player.x,y:player.y};const to={x:target.x,y:target.y};projectile.style.transition="left .18s linear,top .18s linear";
    requestAnimationFrame(()=>{projectile.style.left=to.x+"%";projectile.style.top=to.y+"%";});
    setTimeout(()=>{projectile.remove();if(!$("#battle").classList.contains("active"))return;target.hp-=superAttack?2:1;score+=superAttack?2:1;$("#score").textContent=score;$("#arenaMessage").textContent=target.hp<=0?"Робот повержен!":"Попадание!";renderBots();if(bots.every(b=>b.hp<=0))finishBattle();},190);
  }
  function finishBattle(){if(!$("#battle").classList.contains("active"))return;data.wins++;data.trophies+=8;data.coins+=35;save();$("#arenaMessage").textContent="ПОБЕДА! +35 монет";toast("Победа! Ты получил 35 монет и 8 трофеев.");setTimeout(()=>page("home"),1400);}
  $$("[data-page]").forEach(b=>b.addEventListener("click",()=>page(b.dataset.page)));
  $$("[data-action='play']").forEach(b=>b.addEventListener("click",startBattle));
  $$("[data-action='leave']").forEach(b=>b.addEventListener("click",()=>{page("home");toast("Ты покинул тренировку.");}));
  $("#fighterList").addEventListener("click",e=>{const b=e.target.closest("[data-fighter]");if(!b)return;const i=Number(b.dataset.fighter),f=fighters[i];if(data.owned.includes(i)){data.selected=i;save();renderFighters();toast("Выбран боец: "+f.name);}else if(data.coins>=f.cost){data.coins-=f.cost;data.owned.push(i);data.selected=i;save();renderFighters();toast("Открыт новый боец: "+f.name+"!");}else toast("Не хватает монет!");});
  $$(".buy").forEach(b=>b.addEventListener("click",()=>{const cost=Number(b.dataset.buy);if(data.coins<cost){toast("Не хватает монет!");return;}data.coins-=cost;data.coins+=cost===75?100:220;save();toast("Набор открыт! Монеты начислены.");}));
  $("#dailyBtn").addEventListener("click",()=>{const today=new Date().toDateString();if(data.lastDaily===today){toast("Награда уже получена сегодня!");return;}data.lastDaily=today;data.coins+=100;save();toast("Получено 100 монет!");$("#dailyBtn").textContent="ПОЛУЧЕНО";});
  const controls={up:[0,-5],down:[0,5],left:[-5,0],right:[5,0]};Object.entries(controls).forEach(([id,d])=>{const b=$("#"+id);let interval;const stop=()=>clearInterval(interval);b.addEventListener("pointerdown",e=>{e.preventDefault();move(...d);interval=setInterval(()=>move(...d),160);});["pointerup","pointercancel","pointerleave"].forEach(ev=>b.addEventListener(ev,stop));});
  $("#attackBtn").addEventListener("click",()=>attack(false));$("#superBtn").addEventListener("click",()=>attack(true));
  renderStats();renderFighters();
})();